# __init__.py
from pyplayingcards.playingcards import Deck, suits, values, roll, PlayingCard, PlayingCards

# Version
__version__ = "1.2.4"

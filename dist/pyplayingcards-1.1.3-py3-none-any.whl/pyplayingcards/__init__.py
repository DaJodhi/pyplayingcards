# __init__.py
from pyplayingcards.playingcards import Deck, suits, values, Die, PlayingCard, PlayingCards

# Version
__version__ = "1.1.3"
